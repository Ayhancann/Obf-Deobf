package com.cheatbreaker.obf.utils.asm;

public class NodeAccess {

    public int access;

    public NodeAccess(final int access) {
        this.access = access;
    }

}
